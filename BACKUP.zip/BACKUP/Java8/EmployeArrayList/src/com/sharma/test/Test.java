package com.sharma.test;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;

import static java.util.Comparator.comparingInt;
import static java.util.stream.Collectors.collectingAndThen;
import static java.util.stream.Collectors.toCollection;

public class Test {
	public static void main(String[] args) {
		
		Employee e1 = new Employee(1, "RA", 30);
		Employee e2 = new Employee(1, "RAJ", 31);
		
		List<Employee> l = new ArrayList<>();
		l.add(e1);l.add(e2);
		
		/** Printing original list **/
		System.out.println(l);
		
		
		
		List<Employee> emlList =    (List<Employee>) l.stream()
	    .collect(Collectors.toCollection(
	      () -> new TreeSet<Employee>((p1, p2) ->  Integer.valueOf(p1.getId()).compareTo(Integer.valueOf(p2.getId()))) 
	    		));
		
		
		
		
		
		
		System.out.println(emlList);
		
		
	
		Set<Employee> set = new TreeSet<>( new Comparator<Employee>() {

			@Override
			public int compare(Employee o1, Employee o2) {
				if (o1.getId() == o2.getId())
					return 0;
				return 1;
			}
		});
		
		
		set.addAll(l);

		System.out.println("\n***** After removing duplicates *******\n");

	    final ArrayList newList = new ArrayList(set);

	    /** Printing original list **/
		System.out.println(newList);
		
		
		
		
		
		
		
		List<Employee> unique = l.stream()
                .collect(collectingAndThen(toCollection(() -> new TreeSet<>(comparingInt(Employee::getId))),
                                           ArrayList::new));
		
		
		/** Printing original list **/
		System.out.println(unique);
		
		
	}

}
