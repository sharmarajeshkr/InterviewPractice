package com.sharma.functionalInterface;

@FunctionalInterface
public interface Test {
	public void methodOne();

}
