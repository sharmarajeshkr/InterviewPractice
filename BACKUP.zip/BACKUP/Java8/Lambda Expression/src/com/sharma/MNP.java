package com.sharma;

import com.sharma.functionalInterface.C;

public class MNP implements C {
	
	public static void main(String[] args) {
		C c = () -> System.out.println("Methos 1");		
		c.methodOne();
		c.a1();
		C.a2();
	}

	@Override
	public void methodOne() {
		// TODO Auto-generated method stub
		
	}
	
	
}
