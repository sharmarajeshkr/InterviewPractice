package com.design.solid.liskov_substution_principal.newApproch.userService;

public class UserService {
    public void fetchUserFromAPI(String username, String password) {
        System.out.println("UserService get Data from User API");
    }
}
