package com.design.solid.open_imp_close_modification.newAproach.model;

public enum  Size{
    SMALL,MEDIUM,LARGE,HUGE
}