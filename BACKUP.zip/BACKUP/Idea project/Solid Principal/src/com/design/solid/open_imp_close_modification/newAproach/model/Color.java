package com.design.solid.open_imp_close_modification.newAproach.model;

public enum Color{
    RED,GREEN,BLUE
}
