package com.design.solid.interface_segregation.service_interface.newWay.service_interface;

public interface List<T> {
    public T get();
    public void add(T t);
}
