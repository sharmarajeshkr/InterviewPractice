package com.design.solid.interface_segregation.service_interface.newWay.service_interface;

public interface Deque<T> {
    public T poll();
    public T peek();
}
