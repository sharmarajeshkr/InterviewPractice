package com.design.solid.interface_segregation.service_interface.newWay.List_Implementor;


import com.design.solid.interface_segregation.service_interface.newWay.service_interface.List;

public class ArrayList implements List<Integer> {
    @Override
    public Integer get() {
        return null;
    }

    @Override
    public void add(Integer integer) {

    }

}
