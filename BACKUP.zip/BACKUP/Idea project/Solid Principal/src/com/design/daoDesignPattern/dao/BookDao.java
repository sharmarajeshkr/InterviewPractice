package com.design.daoDesignPattern.dao;

import com.design.daoDesignPattern.model.Books;

import java.util.List;

public interface BookDao<T> {
    List<T> getAllBooks();
    T getBookByIsbn(int isbn);
    void saveBook(T book);
    void deleteBook(T book);
}
