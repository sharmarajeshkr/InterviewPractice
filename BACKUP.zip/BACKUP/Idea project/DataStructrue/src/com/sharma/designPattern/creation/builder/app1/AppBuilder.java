package com.sharma.design.creation.builder.app1;

import com.sharma.design.creation.builder.app1.builders.CarBuilder;
import com.sharma.design.creation.builder.app1.director.Director;

public class AppBuilder {
    public static void main(String[] args) {
        Director director = new Director();

        CarBuilder builder = new CarBuilder();
        director.constructSportsCar(builder);

        //Car car = builder.




    }
}
