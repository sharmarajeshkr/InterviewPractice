package com.sharma.designPattern.miscellaneous.DI.messageService;

public interface MessageService {
    void sendMessage(String msg, String rec);
}
