package com.sharma.design.creation.builder.app1.cars;

public enum Type {
    CITY_CAR, SPORTS_CAR,SUV
}
