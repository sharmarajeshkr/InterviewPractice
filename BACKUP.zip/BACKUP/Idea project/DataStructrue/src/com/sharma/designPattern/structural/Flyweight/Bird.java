package com.sharma.designPattern.structural.Flyweight;

public interface Bird {
    void draw();
}
