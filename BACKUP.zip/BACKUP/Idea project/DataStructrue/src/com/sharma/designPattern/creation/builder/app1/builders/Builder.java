package com.sharma.design.creation.builder.app1.builders;

/*

Builder pattern was introduced to solve some of the
problems with Factory and Abstract Factory design patterns
when the Object contains a lot of attributes.

Builder Design Pattern in Java
Implementation :
    1.  Create a static nested class and then copy all the arguments from the outer class to the Builder class.
        We should follow the naming convention and if the class name is Computer then builder class should be named as ComputerBuilder.
    2.  Java Builder class should have a public constructor with all the required attributes as parameters.
    3.  Java Builder class should have methods to set the optional parameters and it should return the same Builder object after setting the optional attribute.
    4.  The final step is to provide a build() method in the builder class that will return the Object needed by client program.
        For this we need to have a private constructor in the Class with Builder class as argument.
*/

import com.sharma.design.creation.builder.app1.cars.Type;
import com.sharma.design.creation.builder.app1.components.*;

/**
* Builder Interface defines all possible ways to configure a product.
**/
public interface Builder {
    void setType(Type type);
    void setSeats(int seats);
    void setEngine(Engine engine);
    void setTransmission(Transmission transmission);
    void setTripComputer(TripComputer tripComputer);
    void setGPSNavigator(GPSNavigator gpsNavigator);
}

