package com.sharma.designPattern.miscellaneous.DI.messageInjector;

import com.sharma.designPattern.miscellaneous.DI.consumer.Consumer;


public interface MessageServiceInjector {
    public Consumer getConsumer();
}

