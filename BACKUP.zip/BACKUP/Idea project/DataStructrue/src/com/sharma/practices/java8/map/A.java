package com.sharma.practices.java8.map;

import com.sharma.practices.java8.Student;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class A {
    public static void main(String[] args) {

        sortValueByMap();

    }
    // How to Sort Map by values on Increasing order
    //
    //Read more: https://www.java67.com/2017/07/how-to-sort-map-by-values-in-java-8.html#ixzz7wu8iUoBT
    static void sortValueByMap() {
        Map<String, Student> map = new HashMap<String, Student>();
        //Adding elements to map
        map.put("FIVE", new Student("Programming", "Kyle", "Miller", "Miami", 20));
        map.put("FOUR", new Student("Math", "James", "Robertson", "Miami", 20));
        map.put("TWO", new Student("Programming", "Mike", "Miles", "New York", 21));
        map.put("THREE",  new Student("Math", "Michael", "Peterson", "New York", 20));
        map.put("ONE", new Student("Math", "John", "Smith", "Miami", 19));

        map.entrySet()
                .stream()
                .sorted(Map.Entry.<String, Student>comparingByValue())
                .forEach(System.out::println);





    }
}
