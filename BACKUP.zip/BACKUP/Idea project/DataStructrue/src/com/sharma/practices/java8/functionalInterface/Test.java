package com.sharma.practices.java8.functionalInterface;

@FunctionalInterface
public interface Test {
	public void methodOne();

}
