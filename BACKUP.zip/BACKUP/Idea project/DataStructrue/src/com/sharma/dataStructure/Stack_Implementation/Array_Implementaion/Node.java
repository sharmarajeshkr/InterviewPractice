package com.sharma.dataStructure.Stack_Implementation.Array_Implementaion;

public class Node {
	public int data;
	public Node next;
	
	Node(int data){
		this.data = data;
	}
}
