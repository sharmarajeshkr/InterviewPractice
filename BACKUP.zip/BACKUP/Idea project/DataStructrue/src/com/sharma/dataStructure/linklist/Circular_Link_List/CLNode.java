package com.sharma.dataStructure.linklist.Circular_Link_List;


public class CLNode {
	public int data;
	public CLNode next;
	
	CLNode(int data){
		this.data = data;
	}

}