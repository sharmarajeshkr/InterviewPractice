package com.sharma.dataStructure.Other_Files;

public class DLNode {
	int data;
	DLNode prev;
	DLNode next;
	
	DLNode(int data){
		this.data = data;
	}

}
