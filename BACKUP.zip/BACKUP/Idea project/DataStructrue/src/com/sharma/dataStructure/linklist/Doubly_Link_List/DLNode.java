package com.sharma.dataStructure.linklist.Doubly_Link_List;

public class DLNode {
	public int data;
	public DLNode prev;
	public DLNode next;
	
	DLNode(int data){
		this.data = data;
	}

}
