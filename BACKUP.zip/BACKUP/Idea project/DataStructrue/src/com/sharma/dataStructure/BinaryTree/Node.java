package com.sharma.dataStructure.BinaryTree;

public class Node {
	public int data;
	public Node left,right;
	
	Node(int data){
		this.data = data;
		left = right = null;
	}

}
