package com.sharma.dataStructure.Other_Files;


public class CLNode {
	int data;	
	CLNode next;
	
	CLNode(int data){
		this.data = data;
	}

}