package com.sharma.dataStructure.Stack_Implementation.Link_List_Implementation;

public class Node {
	public int data;
	public Node next;
	
	Node(int data){
		this.data = data;
	}
}
