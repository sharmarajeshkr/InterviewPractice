package com.sharma;

import java.util.ArrayList;
import java.util.List;

public class Test {


    static void getList(String str){
        str = "java is    best";
        List<String> listStr = new ArrayList<>();

        char[] ch = str.toCharArray();
        int spaceIndex = 0;
        int wordIndex = 0;
        for (char c : ch){
            if (c == ' ') {
                String test = str.substring(wordIndex,spaceIndex);
                listStr.add(test);
            }else {
                spaceIndex++;
            }

        }







    }



    public static void main(String[] args) {
        // java is    best
        String str = "java is    best";
        StringBuilder bf = new StringBuilder("");

        int spaceIndex = 0;
        int wordStartIndex = 0;

        List<String> ls = new ArrayList<>();
        while (spaceIndex > -1) {
            spaceIndex = str.indexOf(" ", wordStartIndex);
            if (spaceIndex == -1)
                break;
            String s = str.substring(wordStartIndex, spaceIndex);
            if (s.equals("")) {
                wordStartIndex++;
                spaceIndex++;
                continue;
            } else if (s.length() > 0) {
                bf.insert(0, str.substring(wordStartIndex, spaceIndex)).insert(0, ' ');
            } else {
                bf.insert(0, str.subSequence(wordStartIndex, str.length()-1));
            }
            wordStartIndex = spaceIndex + 1;
        }
        /*if (spaceIndex == -1) {
            bf.insert(str.substring(wordStartIndex,str.length()-1));
        }*/
        System.out.println(bf.toString());

    }


}


