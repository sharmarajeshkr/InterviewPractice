package com.sharma.hashing;

import java.util.Hashtable;

public class HashTableApp {
	Hashtable<Integer, Integer> i;

}
